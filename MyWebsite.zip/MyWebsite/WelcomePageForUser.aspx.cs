﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userid"] == null)
            Response.Redirect("LoginForUser.aspx");

        Label1.Text = "Hello! " + Session["userid"].ToString();
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 0;
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 1;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12663;Database=dbGTGeneration;Integrated Security=false;User id=sa;password=System123");
        
        //SqlCommand cmd = new SqlCommand("prcFetchDataFromRoute1");
        
        SqlCommand cmd = new SqlCommand("select * from Route1 where cSourceStation=@cSourceStation and cDestinationStation=@cDestinationStation");
        SqlCommand cmd1 = new SqlCommand("INSERT dtTicketDetailsOfRoute1 select * FROM Route1 WHERE cSourceStation=@cSourceStation and cDestinationStation=@cDestinationStation");
        SqlDataAdapter da = new SqlDataAdapter();
        DataSet ds = new DataSet();
        //cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@cSourceStation",DropDLsource1.SelectedValue);
        cmd.Parameters.AddWithValue("@cDestinationStation", DropDownList4.SelectedValue);
     
        cmd.Connection = con;
        con.Open();
        da.SelectCommand = cmd;
        //da.SelectCommand.ExecuteNonQuery();
        SqlDataReader dr = cmd.ExecuteReader();
        
        if (dr.HasRows)
        {
            if (DropDLsource1.SelectedValue != DropDownList4.SelectedValue)
            { 
            
                con.Close();
                da.Fill(ds, "Route1");
                GridView1.DataSource = ds;
                GridView1.DataBind();
               
                cmd1.Connection = con;
                con.Open();
                cmd1.Parameters.AddWithValue("@cSourceStation", DropDLsource1.SelectedValue);
                cmd1.Parameters.AddWithValue("@cDestinationStation", DropDownList4.SelectedValue);
                cmd1.ExecuteNonQuery();
                DropDLsource1.SelectedValue = null;
                DropDownList4.SelectedValue = null;
            }
           
        }
        else
        {
            Label8.Text = "Invalid source and destination Station combination ";
            DropDLsource1.SelectedValue = null;
            DropDownList4.SelectedValue = null;
        }
       
         
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12663;Database=dbGTGeneration;Integrated Security=false;User id=sa;password=System123");
        //SqlCommand cmd = new SqlCommand("prcFetchDataFromRoute1");
        SqlCommand cmd = new SqlCommand("select * from Route2 where cSourceStation=@cSourceStation and cDestinationStation=@cDestinationStation");
        SqlCommand cmd1 = new SqlCommand("INSERT dtTicketDetailsOfRoute2 select * FROM Route2 WHERE cSourceStation=@cSourceStation and cDestinationStation=@cDestinationStation");
        SqlDataAdapter da = new SqlDataAdapter();
        DataSet ds = new DataSet();
        //cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@cSourceStation",DDL1.SelectedValue);
        cmd.Parameters.AddWithValue("@cDestinationStation", DDL2.SelectedValue);
        cmd.Connection = con;
        con.Open();
        da.SelectCommand = cmd;
        SqlDataReader dr = cmd.ExecuteReader();
        
        if (dr.HasRows)
        {
            if (DDL1.SelectedValue != DDL2.SelectedValue)
            { 
            //Response.Redirect("DisplayTicketForRoute1.aspx");
                con.Close();
                da.Fill(ds, "Route2");
                gv2.DataSource = ds;
                gv2.DataBind();
                cmd1.Connection = con;
                con.Open();
                cmd1.Parameters.AddWithValue("@cSourceStation", DDL1.SelectedValue);
                cmd1.Parameters.AddWithValue("@cDestinationStation", DDL2.SelectedValue);
                cmd1.ExecuteNonQuery();
                DDL1.SelectedValue = null;
                DDL2.SelectedValue = null;
            }
           
        }
        else
        {
            Label9.Text = "Invalid source and destination Station combination ";
            DDL1.SelectedValue = null;
            DDL2.SelectedValue = null;
        }
        
    }

    protected void Button5_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Response.Redirect("LoginForUser.aspx");
    }
    
}