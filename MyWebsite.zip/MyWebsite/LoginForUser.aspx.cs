﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class LoginForUser : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12663;Database=dbGtGeneration;Integrated Security=false;User id=sa;password=System123");
        SqlCommand cmd = new SqlCommand("prcFetchPass");
       
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@userid", txtUserId.Text.Trim());
        cmd.Parameters.AddWithValue("@password", txtPassword.Text.Trim());
        cmd.Connection = con;
        con.Open();
        SqlDataReader dr=cmd.ExecuteReader();
        if(dr.HasRows)
        {
            Session["userid"] = txtUserId.Text;
            Response.Redirect("WelcomePageForUser.aspx");
        }
        else
        {
            Label3.Text = "Invalid userid and password combination ";
        }

    }

}