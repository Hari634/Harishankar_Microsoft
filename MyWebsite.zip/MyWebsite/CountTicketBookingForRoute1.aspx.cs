﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12663;Database=dbGTGeneration;Integrated Security=false;User id=sa;password=System123");
        SqlCommand cmd = new SqlCommand("select count(*) from dtTicketDetailsOfRoute1",con);
        SqlCommand cmd1 = new SqlCommand("Select * from dtTicketDetailsOfRoute1",con);
        SqlDataAdapter da = new SqlDataAdapter();
        
         con.Open();
        
         da.SelectCommand = cmd;
         SqlDataReader dr = cmd.ExecuteReader();
      
       while (dr.Read())
        {
            if (dr.HasRows)
            {
                Label2.Text = dr[0].ToString();
            }
        }
       con.Close();
       DataSet ds = new DataSet();
       con.Open();
      
       da.SelectCommand = cmd1;
       da.Fill(ds, "dtTicketDetailsOfRoute1");
       GridView1.DataSource = ds;
       GridView1.DataBind();
        
    }
   
}