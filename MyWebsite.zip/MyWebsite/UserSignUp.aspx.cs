﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Configuration;

public partial class Default2 : System.Web.UI.Page
{
   

    protected void Page_Load(object sender, EventArgs e)
    {
        //if(Session["cFirstname"]==null)
        
        //{
        //    Response.Redirect("UserSignUp.aspx");

       
    }
    protected void btnRegister_Click(object sender, EventArgs e)
    {

        SqlConnection con = new SqlConnection(@"Server=INBASDPC12663;Database=dbGTGeneration;Integrated Security=false;User id=sa;password=System123");
        int UserId;
        SqlCommand cmd = new SqlCommand("prcInsert_User");
        SqlDataAdapter da = new SqlDataAdapter();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@cFirst_Name", txtFirstname.Text.Trim());
        cmd.Parameters.AddWithValue("@cLast_Name", txtLastName.Text.Trim());
        cmd.Parameters.AddWithValue("@vPassword", txtPassword.Text.Trim());
        cmd.Parameters.AddWithValue("@cGender", RadioButtonList1.SelectedValue);
        cmd.Parameters.AddWithValue("@vEmail", txtEmail.Text.Trim());
        cmd.Parameters.AddWithValue("@vMobile_No", txtMobile.Text.Trim());
        cmd.Parameters.AddWithValue("@dDate_Of_Birth", cal.SelectedDate);
        cmd.Parameters.AddWithValue("@cCity",txtCity.Text.Trim());
        cmd.Parameters.AddWithValue("@cState", txtState.Text.Trim());
        cmd.Parameters.AddWithValue("@cCountry", txtCountry.Text.Trim());
        cmd.Parameters.AddWithValue("@iPin_Code", TxtPinCode.Text.Trim());
        if (txtMobile.Text.Length == 10)
        {
            if (new Date(cal.SelectedDate) > new Date())
            cmd.Connection = con;
            con.Open();
            UserId = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();
            //string messege = string.Empty;
            //messege = "Registraion Successful.\n user Id:" + UserId;
            switch (UserId)
            {
                case -1:
                    Label4.Text = "Email already Exists.\n please choose a different email id";
                    break;
                case -2:
                    Label4.Text = "mobile no is already exists.\n please enter a different mobile no";
                    break;
                default:
                    Label4.Text = "Registration Successful.your user id is :" + UserId;
                    break;
            }
        }
        else
        {
            Label4.Text = "write proper mobile no";
        }
        //ClientScript.RegisterStartupScript(GetType(), "alert", "alert(" + messege + ");", true);
        //MessageBox.Show(messege);
        //Label4.Text = "Registration Successful.your user id is :" + UserId;
        
    }
}