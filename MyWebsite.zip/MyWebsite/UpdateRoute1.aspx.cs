﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 0;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 1;
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 2;
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12663;Database=dbGTGeneration;Integrated Security=false;User id=sa;password=System123");
        SqlCommand cmd = new SqlCommand("prcUpdateSourceandDestinationRoute1");
        SqlDataAdapter da = new SqlDataAdapter();
        cmd.Connection = con;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@serial_no",TextBox3.Text.Trim());
        cmd.Parameters.AddWithValue("@cSourceStation",TextBox1.Text.Trim());
        cmd.Parameters.AddWithValue("@cDestinationStation", TextBox2.Text.Trim());
        con.Open();
        cmd.ExecuteNonQuery();
        Label1.Text = "data updated";
       
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12429\SQLEXPRESS;Database=dbGTGeneration;Integrated Security=false;User id=sa;password=System123");
        SqlCommand cmd = new SqlCommand("prcUpdateFairRoute1");
        SqlDataAdapter da = new SqlDataAdapter();
        cmd.Connection = con;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@serial_no", TextBox4.Text.Trim());
        cmd.Parameters.AddWithValue("@dPrice", TextBox5.Text.Trim());
        
        con.Open();
        cmd.ExecuteNonQuery();
        Label1.Text = "data updated";
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12429\SQLEXPRESS;Database=dbGTGeneration;Integrated Security=false;User id=sa;password=System123");
        SqlCommand cmd = new SqlCommand("prcUpdateDistanceRoute1");
        SqlDataAdapter da = new SqlDataAdapter();
        cmd.Connection = con;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@serial_no", TextBox6.Text.Trim());
        cmd.Parameters.AddWithValue("@dDistance", TextBox7.Text.Trim());
        
        con.Open();
        cmd.ExecuteNonQuery();
        Label1.Text = "data updated";
    }
    protected void Button7_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Response.Redirect("LoginForAdmin.aspx");
    }
    protected void Button9_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Response.Redirect("LoginForAdmin.aspx");
    }
    protected void Button8_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Response.Redirect("LoginForAdmin.aspx");
    }
}