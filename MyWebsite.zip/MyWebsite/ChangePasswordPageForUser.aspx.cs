﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12663;Database=dbGTGeneration;Integrated Security=false;User id=sa;password=System123");
        SqlCommand cmd = new SqlCommand("select * from tblUser where iUserId=@userid and vPassword=@password", con);
        SqlDataAdapter da = new SqlDataAdapter();
        con.Open();
        cmd.Parameters.Add("@userid", TextBox1.Text.Trim());
        cmd.Parameters.Add("@password", TextBox2.Text.Trim());
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            con.Close();
            SqlCommand cmmd = new SqlCommand("update tblUser set vPassword=@password where iUserId=@userid", con);
            cmmd.Parameters.Add("@password", TextBox3.Text.Trim());
            cmmd.Parameters.Add("@userid", TextBox1.Text.Trim());

            con.Open();
            cmmd.ExecuteNonQuery();
            Label5.Text = "password change successfully";
        }
        else
        {
            Label5.Text = "Please enter correct paasword";
        }
    }
}