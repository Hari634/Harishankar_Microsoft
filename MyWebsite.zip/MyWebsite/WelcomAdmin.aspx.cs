﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userid"] == null)
            Response.Redirect("LoginForAdmin.aspx");
        
        Label1.Text = "Hello! "+Session["userid"].ToString();
    }
    protected void Btnshow1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12663;Database=dbGTGeneration;Integrated Security=false;User id=sa;password=System123");
        Route1Information(con);
        Route2Information(con);
        
    }

    private void Route2Information(SqlConnection con)
    {
        if (Dropdownlist1.SelectedIndex == 1)
        {
            SqlCommand cmd = new SqlCommand("select * from Route2");
            SqlDataAdapter da = new SqlDataAdapter();
            cmd.Connection = con;
            con.Open();
            cmd.Connection = con;
            da.SelectCommand = cmd;
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                Response.Redirect("RouteInfo2.aspx");
            }
            else
            {
                Label2.Text = "No item selected";
            }
        }
    }

    private void Route1Information(SqlConnection con)
    {
        if (Dropdownlist1.SelectedIndex == 0)
        {
            SqlCommand cmd = new SqlCommand("select * from Route1");
            SqlDataAdapter da = new SqlDataAdapter();
            cmd.Connection = con;
            con.Open();
            da.SelectCommand = cmd;
            SqlDataReader dr = cmd.ExecuteReader();
            cmd.Connection = con;
            if (dr.HasRows)
            {
                Response.Redirect("RouteInfo1.aspx");
            }
            else
            {
                Label2.Text = "No item selected";
            }
        }
    }
    protected void Btnshow2_Click(object sender, EventArgs e)
    {
        if (Dropdownlist1.SelectedIndex == 0)
        {
        Response.Redirect("CountTicketBookingForRoute1.aspx");
        }
        else if(Dropdownlist1.SelectedIndex == 1)
        {
            Response.Redirect("CountTicketBookingForRoute2.aspx");
        }
    }
    protected void Dropdownlist1_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }
}