﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12663;Database=dbGTGeneration;Integrated Security=false;User id=sa;password=System123");
        SqlCommand cmd = new SqlCommand("select * from Route1");
        SqlDataAdapter da = new SqlDataAdapter();
        DataSet ds = new DataSet();
        cmd.Connection = con;
        con.Open();
        da.SelectCommand = cmd;
        da.Fill(ds, "Route1");
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("UpdateRoute1.aspx");
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Response.Redirect("LoginForAdmin.aspx");
    }
}