﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12663;Database=dbGtGeneration;Integrated Security=false;User id=sa;password=System123");
        SqlCommand cmd = new SqlCommand("prcFetchAdmin");

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@userid", Txtadmin.Text.Trim());
        cmd.Parameters.AddWithValue("@password",Txtpwd.Text.Trim());
        cmd.Connection = con;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();

        if (dr.HasRows)
        {
            Session["userid"] = Txtadmin.Text.ToString();
            Response.Redirect("WelcomAdmin.aspx");

        }
        else
        {
            Label3.Text = "*Invalid userid and password combination ";
        }
        con.Close();
    }
}