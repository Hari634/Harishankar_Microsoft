﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12663;Database=dbGTGeneration;Integrated Security=false;User id=sa;password=System123");
        SqlCommand cmd = new SqlCommand("select * from TrainRoute12");
        SqlDataAdapter da = new SqlDataAdapter();
        DataSet ds = new DataSet();
        cmd.Connection = con;
        con.Open();
        da.SelectCommand = cmd;
        da.Fill(ds, "TrainRoute12");
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
}